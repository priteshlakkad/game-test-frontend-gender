import React from 'react';
import App from 'containers/app/app';
import { render } from 'react-dom';
import { BrowserRouter as Router } from 'react-router-dom';
import 'assets/style/index.less';
if (process.env.NODE_ENV !== 'development') {
  require('disable-react-devtools');
}
const mountNode = document.getElementById('content');

const componentToRender = (
  <Router>
    <App cookie={window.location.pathname} />
  </Router>
);

render(componentToRender, mountNode);
