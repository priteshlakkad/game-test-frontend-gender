export const leftKeyId = 69;
export const rightKeyId = 73;

export const round1Questions = [
  { key: 1, question: 'Raj', ans: 1 },
  { key: 2, question: 'Grandpa', ans: 1 },
  { key: 3, question: 'Rani', ans: 2 },
  { key: 4, question: 'Uncle', ans: 1 },
  { key: 5, question: 'Grandma', ans: 2 },
  { key: 6, question: 'Father', ans: 1 },
  { key: 7, question: 'Aunt', ans: 2 },
  { key: 8, question: 'Brother', ans: 1 },
  { key: 9, question: 'Mother', ans: 2 },
  { key: 10, question: 'Sister', ans: 2 },
  { key: 11, question: 'Queen', ans: 2 },
  { key: 12, question: 'King', ans: 1 },
  { key: 13, question: 'Raj', ans: 1 },
  { key: 14, question: 'Rani', ans: 2 },
  { key: 15, question: 'Grandma', ans: 2 },
  { key: 16, question: 'Grandpa', ans: 1 },
  { key: 17, question: 'Uncle', ans: 1 },
  { key: 18, question: 'Father', ans: 1 },
  { key: 19, question: 'Brother', ans: 1 },
  { key: 20, question: 'King', ans: 1 }
];

export const round2Questions = [
  { key: 1, question: 'Go-getter', ans: 1 },
  { key: 2, question: 'Lack of finance aptitude', ans: 2 },
  { key: 3, question: 'Inability to handle stress', ans: 2 },
  { key: 4, question: 'High Sales', ans: 1 },
  { key: 5, question: 'Content with status-quo', ans: 2 },
  { key: 6, question: 'Frequent absence from work', ans: 2 },
  { key: 7, question: 'All nighter', ans: 1 },
  { key: 8, question: 'Loud', ans: 1 },
  { key: 9, question: 'Aggressive', ans: 1 },
  { key: 10, question: 'Silent', ans: 2 },
  { key: 11, question: 'Limited availability', ans: 2 },
  { key: 12, question: 'Talented', ans: 1 },
  { key: 13, question: 'Gives up easily', ans: 2 },
  { key: 14, question: 'Ambitious', ans: 1 },
  { key: 15, question: 'Supervision required', ans: 2 },
  { key: 16, question: 'Underperform', ans: 2 },
  { key: 17, question: 'Strong Pipeline', ans: 1 },
  { key: 18, question: 'Limited availability', ans: 2 },
  { key: 19, question: 'Lack of interest to learn', ans: 2 },
  { key: 20, question: 'Quick learner', ans: 1 }
];

export const round3Questions = [
  { key: 1, question: 'Aunt', ans: 2 },
  { key: 2, question: 'Frequent absence from work', ans: 2 },
  { key: 3, question: 'Raj', ans: 1 },
  { key: 4, question: 'Talented', ans: 2 },
  { key: 5, question: 'Queen', ans: 1 },
  { key: 6, question: 'Good network', ans: 1 },
  { key: 7, question: 'Mother', ans: 2 },
  { key: 8, question: 'Quick learner', ans: 1 },
  { key: 9, question: 'Grandma', ans: 1 },
  { key: 10, question: 'All nighter', ans: 2 },
  { key: 11, question: 'King', ans: 1 },
  { key: 12, question: 'Limited availability', ans: 2 },
  { key: 13, question: 'Brother', ans: 1 },
  { key: 14, question: 'Inability to handle stress', ans: 2 },
  { key: 15, question: 'Uncle', ans: 1 },
  { key: 16, question: 'Lack of interest to learn', ans: 1 },
  { key: 17, question: 'Father', ans: 2 },
  { key: 18, question: 'Ambitious', ans: 1 },
  { key: 19, question: 'Sister', ans: 2 },
  { key: 20, question: 'High Util', ans: 1 }
];

export const round4Questions = [
  { key: 1, question: 'Father', ans: 1 },
  { key: 2, question: 'Lack of finance aptitude', ans: 2 },
  { key: 3, question: 'Rani', ans: 2 },
  { key: 4, question: 'Go-getter', ans: 1 },
  { key: 5, question: 'Uncle', ans: 1 },
  { key: 6, question: 'Lack of interest to learn', ans: 2 },
  { key: 7, question: 'Sister', ans: 2 },
  { key: 8, question: 'High Sales', ans: 1 },
  { key: 9, question: 'Aunt', ans: 2 },
  { key: 10, question: 'Loud', ans: 2 },
  { key: 11, question: 'Queen', ans: 1 },
  { key: 12, question: 'High Util', ans: 1 },
  { key: 13, question: 'Mother', ans: 2 },
  { key: 14, question: 'Quick learner', ans: 1 },
  { key: 15, question: 'Grandpa', ans: 2 },
  { key: 16, question: 'Content with status-quo', ans: 1 },
  { key: 17, question: 'Father', ans: 1 },
  { key: 18, question: 'Frequent absence from work', ans: 2 },
  { key: 19, question: 'Uncle', ans: 1 },
  { key: 20, question: 'In demand', ans: 1 },
  { key: 21, question: 'Mother', ans: 2 },
  { key: 22, question: 'Good network', ans: 1 },
  { key: 23, question: 'Brother', ans: 1 },
  { key: 24, question: 'Gives up easily', ans: 2 },
  { key: 25, question: 'King', ans: 1 },
  { key: 26, question: 'Silent', ans: 2 },
  { key: 27, question: 'Grandma', ans: 2 },
  { key: 28, question: 'Aggressive', ans: 1 },
  { key: 29, question: 'Sister', ans: 2 },
  { key: 30, question: 'Talented', ans: 2 },
  { key: 31, question: 'Queen', ans: 1 },
  { key: 32, question: 'Ambitious', ans: 1 },
  { key: 33, question: 'Rani', ans: 2 },
  { key: 34, question: 'Supervision required', ans: 2 },
  { key: 35, question: 'Grandpa', ans: 1 },
  { key: 36, question: 'Underperform', ans: 2 },
  { key: 37, question: 'Brother', ans: 1 },
  { key: 38, question: 'Limited availability', ans: 2 },
  { key: 39, question: 'Raj', ans: 2 },
  { key: 40, question: 'Inability to handle stress', ans: 1 }
];

export const round5Questions = [
  { key: 1, question: 'Mother', ans: 1 },
  { key: 2, question: 'Sister', ans: 1 },
  { key: 3, question: 'Queen', ans: 1 },
  { key: 4, question: 'Raj', ans: 2 },
  { key: 5, question: 'Grandma', ans: 1 },
  { key: 6, question: 'Rani', ans: 1 },
  { key: 7, question: 'Uncle', ans: 2 },
  { key: 8, question: 'Father', ans: 2 },
  { key: 9, question: 'Aunt', ans: 1 },
  { key: 10, question: 'Grandpa', ans: 2 },
  { key: 11, question: 'Brother', ans: 2 },
  { key: 12, question: 'King', ans: 2 },
  { key: 13, question: 'Sister', ans: 1 },
  { key: 14, question: 'Uncle', ans: 2 },
  { key: 15, question: 'Mother', ans: 1 },
  { key: 16, question: 'Raj', ans: 2 },
  { key: 17, question: 'Rani', ans: 1 },
  { key: 18, question: 'Grandma', ans: 1 },
  { key: 19, question: 'Father', ans: 2 },
  { key: 20, question: 'Queen', ans: 1 }
];

export const round6Questions = [
  { key: 1, question: 'Rani', ans: 1 },
  { key: 2, question: 'Lack of finance aptitude', ans: 1 },
  { key: 3, question: 'King', ans: 2 },
  { key: 4, question: 'Go-getter', ans: 2 },
  { key: 5, question: 'Queen', ans: 1 },
  { key: 6, question: 'Content with status-quo', ans: 2 },
  { key: 7, question: 'Uncle', ans: 2 },
  { key: 8, question: 'Quick learner', ans: 2 },
  { key: 9, question: 'Raj', ans: 2 },
  { key: 10, question: 'Silent', ans: 2 },
  { key: 11, question: 'Sister', ans: 1 },
  { key: 12, question: 'High Sales', ans: 2 },
  { key: 13, question: 'Grandpa', ans: 1 },
  { key: 14, question: 'Gives up easily', ans: 1 },
  { key: 15, question: 'Grandma', ans: 2 },
  { key: 16, question: 'Supervision required', ans: 1 },
  { key: 17, question: 'Mother', ans: 1 },
  { key: 18, question: 'Underperform', ans: 1 },
  { key: 19, question: 'Aunt', ans: 2 },
  { key: 20, question: 'Ambitious', ans: 1 }
];

export const round7Questions = [
  { key: 1, question: 'Sister', ans: 1 },
  { key: 2, question: 'Supervision required', ans: 2 },
  { key: 3, question: 'Grandpa', ans: 2 },
  { key: 4, question: 'Strong Pipeline', ans: 1 },
  { key: 5, question: 'King', ans: 2 },
  { key: 6, question: 'Go-getter', ans: 2 },
  { key: 7, question: 'Raj', ans: 2 },
  { key: 8, question: 'Lack of finance aptitude', ans: 1 },
  { key: 9, question: 'Grandma', ans: 1 },
  { key: 10, question: 'Aggressive', ans: 1 },
  { key: 11, question: 'Grandpa', ans: 1 },
  { key: 12, question: 'Loud', ans: 1 },
  { key: 13, question: 'Rani', ans: 1 },
  { key: 14, question: 'Content with status-quo', ans: 1 },
  { key: 15, question: 'Aunt', ans: 2 },
  { key: 16, question: 'Limited availability', ans: 2 },
  { key: 17, question: 'Uncle', ans: 2 },
  { key: 18, question: 'In demand', ans: 2 },
  { key: 19, question: 'Father', ans: 2 },
  { key: 20, question: 'Inability to handle stress', ans: 2 },
  { key: 21, question: 'Aunt', ans: 1 },
  { key: 22, question: 'Lack of interest to learn', ans: 1 },
  { key: 23, question: 'Queen', ans: 1 },
  { key: 24, question: 'High Util', ans: 1 },
  { key: 25, question: 'Brother', ans: 1 },
  { key: 26, question: 'All nighter', ans: 1 },
  { key: 27, question: 'Raj', ans: 1 },
  { key: 28, question: 'High Sales', ans: 2 },
  { key: 29, question: 'Father', ans: 2 },
  { key: 30, question: 'Strong Pipeline', ans: 2 },
  { key: 31, question: 'Rani', ans: 2 },
  { key: 32, question: 'Frequent absence from work', ans: 2 },
  { key: 33, question: 'Mother', ans: 2 },
  { key: 34, question: 'Silent', ans: 1 },
  { key: 35, question: 'Grandma', ans: 1 },
  { key: 36, question: 'Good network', ans: 1 },
  { key: 37, question: 'Brother', ans: 1 },
  { key: 38, question: 'In demand', ans: 2 },
  { key: 39, question: 'Mother', ans: 2 },
  { key: 40, question: 'Underperform', ans: 1 }
];

/* --------------------------------------- odd --------------------------------- */

export const oddRound1 = {
  key: 1,
  leftKey: 'Male',
  rightKey: 'Female',
  type: 'Practice',
  noOfTrials: 20,
  questions: round1Questions,
  color: 'black',
};

export const oddRound2 = {
  key: 2,
  leftKey: 'High Performer',
  rightKey: 'Not Career Oriented',
  type: 'Practice',
  noOfTrials: 20,
  questions: round2Questions,
  color: 'green',
};

export const oddRound3 = {
  key: 3,
  leftKey: 'Male + High Perfomer',
  rightKey: 'Female + Not Career Oriented',
  type: 'Practice',
  noOfTrials: 20,
  questions: round3Questions,
  color: 'black + green',
};

export const oddRound4 = {
  key: 4,
  leftKey: 'Male + High Perfomer',
  rightKey: 'Female + Not Career Oriented',
  type: 'Test',
  noOfTrials: 40,
  questions: round4Questions,
  color: 'black + green',
};

export const oddRound5 = {
  key: 5,
  leftKey: 'Female',
  rightKey: 'Male',
  type: 'Practice',
  noOfTrials: 20,
  questions: round5Questions,
  color: 'black',
};

export const oddRound6 = {
  key: 6,
  leftKey: 'Female + High Perfomer',
  rightKey: 'Male + Not Career Oriented',
  type: 'Practice',
  noOfTrials: 20,
  questions: round6Questions,
  color: 'black + green',
};

export const oddRound7 = {
  key: 7,
  leftKey: 'Female + High Perfomer',
  rightKey: 'Male + Not Career Oriented',
  type: 'Test',
  noOfTrials: 40,
  questions: round7Questions,
  color: 'black + green',
};

/* --------------------------------------- even --------------------------------- */

export const evenRound1 = {
  key: 1,
  leftKey: 'Male',
  rightKey: 'Female',
  type: 'Practice',
  noOfTrials: 20,
  questions: round5Questions,
  color: 'black',
};

export const evenRound2 = {
  key: 2,
  leftKey: 'High Performer',
  rightKey: 'Not Career Oriented',
  type: 'Practice',
  noOfTrials: 20,
  questions: round2Questions,
  color: 'green',
};

export const evenRound3 = {
  key: 3,
  leftKey: 'Male + High Perfomer',
  rightKey: 'Female + Not Career Oriented',
  type: 'Practice',
  noOfTrials: 20,
  questions: round6Questions,
  color: 'black + green',
};

export const evenRound4 = {
  key: 4,
  leftKey: 'Male + High Perfomer',
  rightKey: 'Female + Not Career Oriented',
  type: 'Test',
  noOfTrials: 40,
  questions: round7Questions,
  color: 'black + green',
};

export const evenRound5 = {
  key: 5,
  leftKey: 'Female',
  rightKey: 'Male',
  type: 'Practice',
  noOfTrials: 20,
  questions: round1Questions,
  color: 'black',
};

export const evenRound6 = {
  key: 6,
  leftKey: 'Female + High Perfomer',
  rightKey: 'Male + Not Career Oriented',
  type: 'Practice',
  noOfTrials: 20,
  questions: round3Questions,
  color: 'black + green',
};

export const evenRound7 = {
  key: 7,
  leftKey: 'Female + High Perfomer',
  rightKey: 'Male + Not Career Oriented',
  type: 'Test',
  noOfTrials: 40,
  questions: round4Questions,
  color: 'black + green',
};

export const oddTotalRounds = [
  oddRound1,
  oddRound2,
  oddRound3,
  oddRound4,
  oddRound5,
  oddRound6,
  oddRound7,
];

export const evenTotalRounds = [
  evenRound1,
  evenRound2,
  evenRound3,
  evenRound4,
  evenRound5,
  evenRound6,
  evenRound7,
];
