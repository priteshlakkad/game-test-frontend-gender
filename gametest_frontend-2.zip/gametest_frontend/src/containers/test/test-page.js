import React, { Component } from 'react';
import superagent from 'superagent';
import { Button, Form } from 'semantic-ui-react';
import { withRouter } from 'react-router-dom';
import GameBox from './components/game-box';
class TestPage extends Component {
  state = {
    gameStarted: false,
    id: null,
    even: false,
    formData: {
      userName: Math.random().toString(36),
    },
    iat: ''
  };

  handleSubmit = () => {
    const { name, email } = this.state.formData;
    // const allowedEmails = [
    //   'aditibharath.ext@deloitte.com',
    //   'kalmuppa@deloitte.com',
    //   'dibyomukherjee@deloitte.com'
    // ];
    console.log('name-->', name, email);
    if (name && email) {
      //if (allowedEmails.includes(email)) {
      superagent
        .post('/api/testdata')
        .send(this.state.formData)
        .then(({ body }) => {
          this.setState({
            gameStarted: true,
            even: body.even,
            id: body.id,
          });
          console.log(body);
        })
        .catch(() => {
          console.log('error');
        });
      // } else {
      //   alert('Please Enter Correct Email id');
      //}
    } else {
      alert('Please fill the details');
    }
  };

  handleSave = () => {
    // eslint-disable-next-line
    // debugger;
    superagent
      .post('/api/testdata')
      .send({ ...this.state.formData, id: this.state.id })
      .then((res) => {
        console.log(res.body);
        this.setState({ iat: res.body.iat });
      })
      .catch(() => {
        console.log('error');
      });
  };

  handleChange = (change) => {
    const newState = {
      formData: {
        ...this.state.formData,
        ...change,
      },
    };
    this.setState(newState);
  };
  render() {
    const { formData } = this.state;
    if (!this.state.gameStarted) {
      return (
        <div>
          <Form>
            <Form.Group widths="equal">
              <Form.Field>
                <label htmlFor="name">
                  Please enter your full Name:
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  placeholder="Enter your name"
                  value={formData.name}
                  onChange={(e) => this.handleChange({ name: e.target.value })}
                /></Form.Field>
              <Form.Field>
                <label htmlFor="email">
                  Please enter your deloitte email address:
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  placeholder="Enter your email address"
                  value={formData.email}
                  onChange={(e) => this.handleChange({ email: e.target.value })}
                />
              </Form.Field>
            </Form.Group>
            {/*<Form.Group widths="equal">
              <Form.Field>
                <label htmlFor="role">Please enter your role</label>
                <Dropdown
                  options={[
                    { text: 'Analyst', value: 'Analyst' },
                    { text: 'Consultant', value: 'Consultant' },
                    { text: 'Senior Consultant', value: 'Senior Consultant' },
                    { text: 'Manager', value: 'Manager' },
                    { text: 'Associate Director', value: 'Associate Director' },
                    { text: 'Director', value: 'Director' },
                    { text: 'Partner', value: 'Partner' },
                  ]}
                  selection
                  fluid
                  onChange={(e, v) => this.handleChange({ role: v.value })}
                  value={formData.role}
                />
              </Form.Field>
              <Form.Field></Form.Field>
                </Form.Group>*/}
          </Form>
          <div className="content text-center mar-t-20">
            <p>
              In the next task, you will be presented with a set of words to
              classify into groups. This task requires that you classify items
              as quickly as you can while making as few mistakes as possible.
              Going too slow or making too many mistakes will result in an
              uninterpretable score. This part of the study will take about 3
              minutes.
            </p>
            <br />
            <p>
              <b>
                <span className="highlight">
                  Kindly read the following list of category labels and the
                  items that belong to each of these categories.
                </span>
              </b>
            </p>
            <div
              style={{
                marginTop: '20px',
                marginBottom: '20px',
                textAlign: 'left',
                display: 'flex',
                justifyContent: 'center',
              }}
            >
              <table className="info-table" cellSpacing={'10px'}>
                <tr>
                  <th style={{ minWidth: '250px' }}>Category</th>
                  <th>Items</th>
                </tr>
                <tr>
                  <td>Male</td>
                  <td>Raj, Grandpa, Rani, Uncle, Grandma, Father, Aunt, Brother, Mother, Sister, Queen, King, Raj, Rani,
                     Grandma, Grandpa, Uncle</td>
                </tr>
                <tr>
                  <td>Female</td>
                  <td>Rani, Uncle, Grandma, Father, Aunt, Brother, Mother, Sister, Queen, King, Raj, Rani, Grandma</td>
                </tr>
                <tr>
                <td>High Performer</td>
                <td>Go-getter, High Sales, Talented, Ambitious, Strong Pipeline, Quick learner</td>
                </tr>
                <tr>
                <td>Not Career Oriented</td>
                <td>Lack of finance aptitude, Inability to handle stress, Frequent absence from work,
                  Silent, Limited availability, Gives up easily, Underperform</td>
                </tr>
              </table>
            </div>
            <h1>Keep in mind</h1>
            <div
              style={{
                textAlign: 'left',
                display: 'flex',
                justifyContent: 'center',
              }}
            >
              <ol>
                <li>
                  Keep your fingers on the{' '}
                  <span className="highlight">'e' and 'i'</span> keys to enable
                  rapid response. ‘e’ for left and ‘i’ for right.
                </li>
                <li>
                  Two labels at the top will tell you which words go with each
                  key.
                </li>
                <li>Each word has a correct classification.</li>
                <li>
                  The test gives no results if you go slow -- Please try to go
                  as fast as possible.
                </li>
                <li>
                  Expect to make a few mistakes because of going fast. That's
                  OK.
                </li>
                <li>For best results, avoid distractions and stay focused.</li>
              </ol>
            </div>
            <br />
            <p>
              This is a timed sorting test. GO AS FAST AS YOU CAN while making
              AS FEW MISTAKES AS POSSIBLE.
            </p>
          </div>
          <div className="flex content-center mar-t-20">
            <Button type="button" onClick={this.handleSubmit}>
              Start Game
            </Button>
          </div>
        </div>
      );
    }
    return (
      <GameBox
        formData={this.state.formData}
        iat={this.state.iat}
        onChange={(change) =>
          this.handleChange({
            listAns: [
              ...(this.state.formData.listAns || []),
              ...(change.listAns || []),
            ],
          })
        }
        onSubmit={this.handleSave}
        even={this.state.even}
      />
    );
  }
}

export default withRouter(TestPage);
