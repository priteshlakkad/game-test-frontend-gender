export const leftKeyId = 69;
export const rightKeyId = 73;

export const round1Questions = [
  { key: 1, question: 'Adore', ans: 1 },
  { key: 2, question: 'Celebrate', ans: 1 },
  { key: 3, question: 'Sadness', ans: 2 },
  { key: 4, question: 'Delight', ans: 1 },
  { key: 5, question: 'Selfish', ans: 2 },
  { key: 6, question: 'Friendship', ans: 1 },
  { key: 7, question: 'Fabulous', ans: 1 },
  { key: 8, question: 'Horrible', ans: 2 },
  { key: 9, question: 'Detest', ans: 2 },
  { key: 10, question: 'Cherish', ans: 1},
  { key: 11, question: 'Lovely', ans: 1 },
  { key: 12, question: 'Scorn', ans: 2 },
  { key: 13, question: 'Adore', ans: 1 },
  { key: 14, question: 'Nasty', ans: 2 },
  { key: 15, question: 'Cheerful', ans: 1 },
  { key: 16, question: 'Celebrate', ans: 1 },
  { key: 17, question: 'Scorn', ans: 2 },
  { key: 18, question: 'Cherish', ans: 1 },
  { key: 19, question: 'Pain', ans: 2 },
  { key: 20, question: 'Rotten', ans: 2 },
];
export const round2Questions = [
  { key: 1, question: 'Gay People', ans: 1 },
  { key: 2, question: 'Homosexual', ans: 1 },
  { key: 3, question: 'Heterosexual', ans: 2 },
  { key: 4, question: 'Straight', ans: 2 },
  { key: 5, question: 'Gay', ans: 1 },
  { key: 6, question: 'Straigh People', ans: 2 },
  { key: 7, question: 'Image- 2 Men Icon', ans: 1 },
  { key: 8, question: 'Homosexual', ans: 1 },
  { key: 9, question: 'Straight', ans: 2 },
  { key: 10, question: 'Image- Woman and Man', ans: 2 },
  { key: 11, question: 'Gay', ans: 1 },
  { key: 12, question: 'Heterosexual', ans: 2 },
  { key: 13, question: 'Gay People', ans: 1 },
  { key: 14, question: 'Image- 2 Men Icon', ans: 1 },
  { key: 15, question: 'Straight', ans: 2 },
  { key: 16, question: 'Gay Men', ans: 1 },
  { key: 17, question: 'Straigh People', ans: 2 },
  { key: 18, question: 'Image- Woman and Man', ans: 2 },
  { key: 19, question: 'Homosexual', ans: 1 },
  { key: 20, question: 'Image- 2 Men Icon', ans: 1 },
];

export const round3Questions = [
  { key: 1, question: 'Delight', ans: 1 },
  { key: 2, question: 'Gay Men', ans: 2 },
  { key: 3, question: 'Sadness', ans: 2 },
  { key: 4, question: 'Gay', ans: 2 },
  { key: 5, question: 'Selfish', ans: 2 },
  { key: 6, question: 'Gay', ans: 1 },
  { key: 7, question: 'Fabulous', ans: 1 },
  { key: 8, question: 'Lovely', ans: 1 },
  { key: 9, question: 'Detest', ans: 2 },
  { key: 10, question: 'Straight', ans: 2 },
  { key: 11, question: 'Lovely', ans: 1 },
  { key: 12, question: 'Gay', ans: 1 },
  { key: 13, question: 'Adore', ans: 1 },
  { key: 14, question: 'Gay People', ans: 1 },
  { key: 15, question: 'Cheerful', ans: 1 },
  { key: 16, question: 'Gay Men', ans: 1 },
  { key: 17, question: 'Scorn', ans: 2 },
  { key: 18, question: 'Image- Woman and Man', ans: 2 },
  { key: 19, question: 'Straigh People', ans: 2 },
  { key: 20, question: 'Celebrate', ans: 1 },
];

export const round4Questions = [
  { key: 1, question: 'Adore', ans: 1 },
  { key: 2, question: 'Gay People', ans: 1 },
  { key: 3, question: 'Celebrate', ans: 1 },
  { key: 4, question: 'Homosexual', ans: 1 },
  { key: 5, question: 'Sadness', ans: 2 },
  { key: 6, question: 'Gay', ans: 1 },
  { key: 7, question: 'Delight', ans: 1 },
  { key: 8, question: 'Gay Men', ans: 1 },
  { key: 9, question: 'Selfish', ans: 2 },
  { key: 10, question: 'Gay', ans: 1 },
  { key: 11, question: 'Friendship', ans: 1 },
  { key: 12, question: 'Straigh People', ans: 2 },
  { key: 13, question: 'Fabulous', ans: 1 },
  { key: 14, question: 'Lovely', ans: 1 },
  { key: 15, question: 'Horrible', ans: 2 },
  { key: 16, question: 'Homosexual', ans: 1 },
  { key: 17, question: 'Detest', ans: 2 },
  { key: 18, question: 'Straight', ans: 2 },
  { key: 19, question: 'Cherish', ans: 1 },
  { key: 20, question: 'Image- Woman and Man', ans: 2 },
  { key: 21, question: 'Lovely', ans: 1 },
  { key: 22, question: 'Gay', ans: 1 },
  { key: 23, question: 'Scorn', ans: 2 },
  { key: 24, question: 'Gay People', ans: 1 },
  { key: 25, question: 'Nasty', ans: 2 },
  { key: 26, question: 'Image- 2 Men Icon', ans: 1 },
  { key: 27, question: 'Cheerful', ans: 1 },
  { key: 28, question: 'Straight', ans: 2 },
  { key: 29, question: 'Celebrate', ans: 1 },
  { key: 30, question: 'Gay People', ans: 1 },
  { key: 31, question: 'Scorn', ans: 2 },
  { key: 32, question: 'Straigh People', ans: 2 },
  { key: 33, question: 'Cherish', ans: 1 },
  { key: 34, question: 'Image- Woman and Man', ans: 2 },
  { key: 35, question: 'Pain', ans: 2 },
  { key: 36, question: 'Homosexual', ans: 1 },
  { key: 37, question: 'Rotten', ans: 2 },
  { key: 38, question: 'Nasty', ans: 2 },
  { key: 39, question: 'Adore', ans: 1 },
  { key: 40, question: 'Gay People', ans: 1 },
];

export const round5Questions = [
  { key: 1, question: 'Adore', ans: 2 },
  { key: 2, question: 'Celebrate', ans: 1 },
  { key: 3, question: 'Sadness', ans: 1 },
  { key: 4, question: 'Delight', ans: 2 },
  { key: 5, question: 'Selfish', ans: 2 },
  { key: 6, question: 'Friendship', ans: 1 },
  { key: 7, question: 'Fabulous', ans: 2 },
  { key: 8, question: 'Horrible', ans: 1 },
  { key: 9, question: 'Detest', ans: 1 },
  { key: 10, question: 'Cherish', ans: 2 },
  { key: 11, question: 'Lovely', ans: 2 },
  { key: 12, question: 'Scorn', ans: 2 },
  { key: 13, question: 'Adore', ans: 2 },
  { key: 14, question: 'Nasty', ans: 2 },
  { key: 15, question: 'Cheerful', ans: 1 },
  { key: 16, question: 'Celebrate', ans: 1 },
  { key: 17, question: 'Scorn', ans: 2 },
  { key: 18, question: 'Cherish', ans: 1 },
  { key: 19, question: 'Pain', ans: 2 },
  { key: 20, question: 'Rotten', ans: 1 },
];

export const round6Questions = [
  { key: 1, question: 'Gay People', ans: 1 },
  { key: 2, question: 'Adore', ans: 2 },
  { key: 3, question: 'Homosexual', ans: 1 },
  { key: 4, question: 'Celebrate', ans: 2 },
  { key: 5, question: 'Gay', ans: 1 },
  { key: 6, question: 'Sadness', ans: 1 },
  { key: 7, question: 'Scorn', ans: 1 },
  { key: 8, question: 'Delight', ans: 2 },
  { key: 9, question: 'Straigh People', ans: 2 },
  { key: 10, question: 'Selfish', ans: 1 },
  { key: 11, question: 'Detest', ans: 1 },
  { key: 12, question: 'Fabulous', ans: 2 },
  { key: 13, question: 'Homosexual', ans: 1 },
  { key: 14, question: 'Horrible', ans: 1 },
  { key: 15, question: 'Pain', ans: 1 },
  { key: 16, question: 'Detest', ans: 1 },
  { key: 17, question: 'Image- Woman and Man', ans: 2 },
  { key: 18, question: 'Cherish', ans: 1 },
  { key: 19, question: 'Gay', ans: 1 },
  { key: 20, question: 'Lovely', ans: 2 },
];

export const round7Questions = [
  { key: 1, question: 'Fabulous', ans: 2 },
  { key: 2, question: 'Scorn', ans: 1 },
  { key: 3, question: 'Horrible', ans: 1 },
  { key: 4, question: 'Homosexual', ans: 1 },
  { key: 5, question: 'Detest', ans: 1 },
  { key: 6, question: 'Gay People', ans: 1 },
  { key: 7, question: 'Celebrate', ans: 2 },
  { key: 8, question: 'Homosexual', ans: 1 },
  { key: 9, question: 'Gay', ans: 1 },
  { key: 10, question: 'Delight', ans: 2 },
  { key: 11, question: 'Sadness', ans: 1 },
  { key: 12, question: 'Gay Men', ans: 1 },
  { key: 13, question: 'Straigh People', ans: 2 },
  { key: 14, question: 'Selfish', ans: 1 },
  { key: 15, question: 'Straight', ans: 2 },
  { key: 16, question: 'Celebrate', ans: 2 },
  { key: 17, question: 'Scorn', ans: 1 },
  { key: 18, question: 'Straight', ans: 2 },
  { key: 19, question: 'Horrible', ans: 1 },
  { key: 20, question: 'Pain', ans: 1 },
  { key: 21, question: 'Image- 2 Men Icon', ans: 1 },
  { key: 22, question: 'Straight', ans: 2 },
  { key: 23, question: 'Scorn', ans: 1 },
  { key: 24, question: 'Cherish', ans: 2 },
  { key: 25, question: 'Rotten', ans: 1 },
  { key: 26, question: 'Gay', ans: 1 },
  { key: 27, question: 'Sadness', ans: 1 },
  { key: 28, question: 'Image- Woman and Man', ans: 2 },
  { key: 29, question: 'Adore', ans: 2 },
  { key: 30, question: 'Gay', ans: 1 },
  { key: 31, question: 'Friendship', ans: 2 },
  { key: 32, question: 'Straigh People', ans: 2 },
  { key: 33, question: 'Delight', ans: 2 },
  { key: 34, question: 'Homosexual', ans: 1 },
  { key: 35, question: 'Cherish', ans: 2 },
  { key: 36, question: 'Gay Men', ans: 1 },
  { key: 37, question: 'Lovely', ans: 2 },
  { key: 38, question: 'Gay Men', ans: 1 },
  { key: 39, question: 'Image- Woman and Man', ans: 2 },
  { key: 40, question: 'Adore', ans: 2 },
];

/* --------------------------------------- odd --------------------------------- */

export const oddRound1 = {
  key: 1,
  leftKey: 'Good',
  rightKey: 'Bad',
  type: 'Practice',
  noOfTrials: 20,
  questions: round1Questions,
  color: 'black',
};

export const oddRound2 = {
  key: 2,
  leftKey: 'Gay People',
  rightKey: 'StraightPeople',
  type: 'Practice',
  noOfTrials: 20,
  questions: round2Questions,
  color: 'green',
};

export const oddRound3 = {
  key: 3,
  leftKey: 'Good + Gay People',
  rightKey: 'Bad + StaightPeople',
  type: 'Practice',
  noOfTrials: 20,
  questions: round3Questions,
  color: 'black + green',
};

export const oddRound4 = {
  key: 4,
  leftKey: 'Good + Gay People',
  rightKey: 'Bad + StaightPeople',
  type: 'Test',
  noOfTrials: 40,
  questions: round4Questions,
  color: 'black + green',
};

export const oddRound5 = {
  key: 5,
  leftKey: 'Bad',
  rightKey: 'Good',
  type: 'Practice',
  noOfTrials: 20,
  questions: round5Questions,
  color: 'black',
};

export const oddRound6 = {
  key: 6,
  leftKey: 'Bad + Gay People',
  rightKey: 'Good + StaightPeople',
  type: 'Practice',
  noOfTrials: 20,
  questions: round6Questions,
  color: 'black + green',
};

export const oddRound7 = {
  key: 7,
  leftKey: 'Bad + Gay People',
  rightKey: 'Good + StaightPeople',
  type: 'Test',
  noOfTrials: 40,
  questions: round7Questions,
  color: 'black + green',
};

/* --------------------------------------- even --------------------------------- */

export const evenRound1 = {
  key: 1,
  leftKey: 'Good',
  rightKey: 'Bad',
  type: 'Practice',
  noOfTrials: 20,
  questions: round5Questions,
  color: 'black',
};

export const evenRound2 = {
  key: 2,
  leftKey: 'Gay People',
  rightKey: 'StaightPeople',
  type: 'Practice',
  noOfTrials: 20,
  questions: round2Questions,
  color: 'green',
};

export const evenRound3 = {
  key: 3,
  leftKey: 'Good + Gay People',
  rightKey: 'Bad + StaightPeople',
  type: 'Practice',
  noOfTrials: 20,
  questions: round6Questions,
  color: 'black + green',
};

export const evenRound4 = {
  key: 4,
  leftKey: 'Good + Gay People',
  rightKey: 'Bad + StaightPeople',
  type: 'Test',
  noOfTrials: 40,
  questions: round7Questions,
  color: 'black + green',
};

export const evenRound5 = {
  key: 5,
  leftKey: 'Bad',
  rightKey: 'Good',
  type: 'Practice',
  noOfTrials: 20,
  questions: round1Questions,
  color: 'black',
};

export const evenRound6 = {
  key: 6,
  leftKey: 'Bad+Gay People',
  rightKey: 'Good + StaightPeople',
  type: 'Practice',
  noOfTrials: 20,
  questions: round3Questions,
  color: 'black + green',
};

export const evenRound7 = {
  key: 7,
  leftKey: 'Bad + Gay People',
  rightKey: 'Good + StaightPeople',
  type: 'Test',
  noOfTrials: 40,
  questions: round4Questions,
  color: 'black + green',
};

export const oddTotalRounds = [
  oddRound1,
  oddRound2,
  oddRound3,
  oddRound4,
  oddRound5,
  oddRound6,
  oddRound7,
];

export const evenTotalRounds = [
  evenRound1,
  evenRound2,
  evenRound3,
  evenRound4,
  evenRound5,
  evenRound6,
  evenRound7,
];
