import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import { Button } from 'semantic-ui-react';
class Round6 extends Component {
  render() {
    return (
      <div>
        <h1 className="text-center">INSTRUCTIONS FOR ROUND 6</h1>
        <div className="content text-center">
          <p>
            OBSERVE, the 4 categories you saw separately now{' '}
            <span className="highlight">appear in pairs</span>. Remember the
            item still belongs to only one category. The green / black colours
            will help you identify the appropriate category. When an item
            belongs to the category on the left, press ‘e’ and similarly for
            item on the category to the right, press ‘i’. If you make an error,
            it will be prompted. You can fix the error by pressing the corect
            key again.
          </p>
        </div>
        <div className="flex content-center mar-t-20">
          <Button onClick={this.props.onClick}>Start Round 6</Button>
        </div>
      </div>
    );
  }
}

export default withRouter(Round6);
