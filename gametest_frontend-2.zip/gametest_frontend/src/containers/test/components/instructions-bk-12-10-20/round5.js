import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import { Button } from 'semantic-ui-react';
class Round5 extends Component {
  render() {
    return (
      <div>
        <h1 className="text-center">INSTRUCTIONS FOR ROUND 5</h1>
        <div className="content text-center">
          <p>
            Observe carefully, there are only 2 categories now and they have{' '}
            <span className="highlight">switched positions</span>. Category
            which was previously on the left is now on the right and vice versa.
          </p>
          <br />
          <p>
            When an item belongs to the category on the left, press ‘e’ and
            similarly for item on the category to the right, press ‘i’. If you
            make an error, it will be prompted. You can fix the error by
            pressing the correct key again.
          </p>
        </div>
        <div className="flex content-center mar-t-20">
          <Button onClick={this.props.onClick}>Start Round 5</Button>
        </div>
      </div>
    );
  }
}

export default withRouter(Round5);
