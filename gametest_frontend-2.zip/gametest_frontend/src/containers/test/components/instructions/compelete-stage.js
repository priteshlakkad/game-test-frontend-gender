import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
class CompleteStage extends Component {
  componentDidUpdate(prevProps) {
    // Check if the `iat` prop has changed
    if (this.props.iat !== prevProps.iat) {
      // Perform any actions or trigger a re-render if needed
      console.log('iat prop has changed:', this.props.iat);
    }
  }
  componentDidMount() {
    setTimeout(() => {
      this.props.onSubmit();
    }, 300);
  }
  render() {
    console.log('render-calling', this.props.iat);
    const { iat } = this.props;
    return (
      <div>
        <div className="content text-center">
          <p>
            <b>
              Thank you for taking this test. You have invested your valuable
              time to make an impact that matters!
            </b>
            <br />
            <b style={{ marginTop: '0.5rem' }}>
            {iat === '' ? 'We are calculating your score... ' : 'Your score is:' + iat }
            </b>
            <br />
            <img src="./Gender.png" alt="test" style={{ marginTop: '0.5rem' }} />
          </p>
          <br />
          <p>
            <b>Team DIAT</b>
          </p>
        </div>
      </div>
    );
  }
}

export default withRouter(CompleteStage);
