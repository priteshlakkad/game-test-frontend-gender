import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import Box from './box';
import OddRound1 from './instructions/odd-round1';
import OddRound2 from './instructions/odd-round2';
import OddRound3 from './instructions/odd-round3';
import OddRound4 from './instructions/odd-round4';
import CompleteStage from './instructions/compelete-stage';
import { oddTotalRounds, evenTotalRounds } from '../utils';
class GameBox extends Component {
  static defaultProps = {
    formData: {},
  };
  state = {
    currentRoundKey: 1,
    running: false,
  };
  handleChangeAnswer = (change) => {
    this.props.onChange(change);
    this.setState({
      currentRoundKey: this.state.currentRoundKey + 1,
      running: false,
    });
  };

  getRound = (key) => {
    const totalRounds = this.props.even ? evenTotalRounds : oddTotalRounds;
    return totalRounds.find((r) => key === r.key);
  };

  handleStartRound = () => {
    this.setState({ running: true });
  };
  getInstructionComponent = () => {
    const { currentRoundKey } = this.state;
    if (currentRoundKey === 1) {
      return <OddRound1 onClick={this.handleStartRound} roundNumber={1} />;
    }
    if (currentRoundKey === 2) {
      return <OddRound2 onClick={this.handleStartRound} roundNumber={2} />;
    }
    if (currentRoundKey === 3) {
      return <OddRound3 onClick={this.handleStartRound} roundNumber={3} />;
    }
    if (currentRoundKey === 4) {
      return <OddRound4 onClick={this.handleStartRound} roundNumber={4} />;
    }
    if (currentRoundKey === 5) {
      return <OddRound1 onClick={this.handleStartRound} roundNumber={5} />;
    }
    if (currentRoundKey === 6) {
      return <OddRound3 onClick={this.handleStartRound} roundNumber={6} />;
    }
    if (currentRoundKey === 7) {
      return <OddRound4 onClick={this.handleStartRound} roundNumber={7} />;
    }
    if (currentRoundKey === 8) {
      return (
        <CompleteStage iat={this.props.iat} onSubmit={this.props.onSubmit} even={this.props.even} />
      );
    }
  };

  render() {
    if (!this.state.running) {
      return <div>{this.getInstructionComponent()}</div>;
    }console.log('this is', this.props.formData, this.props.iat);
    return (
      <div className="flex content-center">
        <Box
          round={this.getRound(this.state.currentRoundKey)}
          onChange={this.handleChangeAnswer}
        />
      </div>
    );
  }
}

export default withRouter(GameBox);
