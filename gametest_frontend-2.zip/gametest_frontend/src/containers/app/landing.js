import React, { Component } from 'react';
import { withRouter, NavLink } from 'react-router-dom';
import { Button } from 'semantic-ui-react';
class LandingPage extends Component {
  render() {
    return (
      <div>
        <h1 className="text-center">Introduction</h1>
        <div className="content text-center">
          <p>
            You are about to take a standard test designed by researchers to
            understand our unconscious biases. Kindly note, this is an anonymous
            test, and results are interpreted for a group of test takers. Your
            responses will be compiled and interpreted based on prior research
            in the field of implicit bias.
          </p>
          <br />
          <p>
            <b>Data Privacy Disclaimer:</b> This is an anonymous test.
            Information shared by you such as Gender and Age will be securely
            stored and will be used only for statistical analysis.
          </p>
          <h1>Instructions</h1>
          <p>
            Kindly read the following instructions carefully before you start
            the test. It is important that you make minimum mistakes during the
            test
          </p>
          <div
            style={{
              textAlign: 'left',
              display: 'flex',
              justifyContent: 'center',
            }}
          >
            <ol>
              <li>Test has 7 rounds, and each round is equally important</li>
              <li>Test should take you maximum 3 minutes to complete</li>
              <li>
                You will be asked to sort words into groups as fast as you can
              </li>
              <li>
                Make the decisions (press keys) as fast as possible during the
                test
              </li>
              <li>
                Test cannot be paused in between, hence you need to take this
                test in one go
              </li>
            </ol>
          </div>
          <p>
            For best results, minimise distractions in your environment and
            close other programs running in the background
          </p>
        </div>
        <div className="flex content-center mar-t-20">
          <NavLink to="/test">
            <Button>Click To Start</Button>
          </NavLink>
        </div>
      </div>
    );
  }
}

export default withRouter(LandingPage);
