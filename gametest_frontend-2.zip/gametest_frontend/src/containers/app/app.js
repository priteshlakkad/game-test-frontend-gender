import React from 'react'; // eslint-disable-line
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import NotFound from 'containers/not-found';
import LandingPage from 'containers/app/landing';
import TestPage from 'containers/test/test-page';
import ListPage from 'containers/test/list-page';

class App extends React.Component {
  render() {
    return (
      <Router>
        <div className="wrapper">
          <Switch>
            <Route exact path="/" component={LandingPage} />
            <Route exact path="/test" component={TestPage} />
            <Route exact path="/admin" component={ListPage} />
            <Route component={NotFound} />
          </Switch>
        </div>
      </Router>
    );
  }
}

export default App;
