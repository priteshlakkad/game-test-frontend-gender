import React, { Component } from 'react';
class NotFound extends Component {
  render() {
    return <h1>not found</h1>;
  }
}

export default NotFound;
