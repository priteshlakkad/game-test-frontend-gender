const path = require('path');
const webpack = require('webpack');
const eslintFormatter = require('react-dev-utils/eslintFormatter');
const CompressionPlugin = require('compression-webpack-plugin');
const fs = require('fs');
const url = require('url');
const chalk = require('chalk');
const pkgJson = require('./package.json');

const appDirectory = fs.realpathSync(process.cwd());
const resolveApp = (relativePath) => path.resolve(appDirectory, relativePath);

const CSS_PATH = 'static/css/';
const JS_PATH = 'static/js/';
const MEDIA_PATH = 'static/media/';

module.exports = (args) => ({
  type: 'react-app',
  polyfill: false,
  babel: {
    presets: ['react-app', 'es2015', 'stage-2'],
    ...(args.command === 'build'
      ? {}
      : {
          plugins: ['react-hot-loader/babel'],
        }),
  },
  webpack: {
    aliases: {
      src: resolveApp('src'),
    },
    html: {
      ...(args.command === 'build'
        ? {
            minify: {
              removeComments: true,
              collapseWhitespace: true,
              removeRedundantAttributes: true,
              useShortDoctype: true,
              removeEmptyAttributes: true,
              removeStyleLinkTypeAttributes: true,
              keepClosingSlash: true,
              minifyJS: true,
              minifyCSS: true,
              minifyURLs: true,
            },
          }
        : {}),
    },
    rules: {
      style: {
        sourceMap: true,
      },
      postcss: {
        sourceMap: true,
      },
      css: {
        sourceMap: true,
      },
      'less-style': {
        sourceMap: true,
      },
      'less-css': {
        sourceMap: true,
      },
      less: {
        sourceMap: true,
      },
      'less-postcss': {
        sourceMap: true,
      },
      fonts: {
        name:
          args.command === 'build'
            ? `${MEDIA_PATH}[name].[hash:8].[ext]`
            : `${MEDIA_PATH}[name].[ext]`,
      },
      svg: {
        name:
          args.command === 'build'
            ? `${MEDIA_PATH}[name].[hash:8].[ext]`
            : `${MEDIA_PATH}[name].[ext]`,
      },
      graphics: {
        limit: 10000,
        name:
          args.command === 'build'
            ? `${MEDIA_PATH}[name].[hash:8].[ext]`
            : `${MEDIA_PATH}[name].[ext]`,
      },
      jpeg: {
        limit: 10000,
        name:
          args.command === 'build'
            ? `${MEDIA_PATH}[name].[hash:8].[ext]`
            : `${MEDIA_PATH}[name].[ext]`,
      },
    },
    compat: {
      moment: ['en-us'],
    },
    define: {
      __CLIENT__: true,
      __SERVER__: false,
      __DEVELOPMENT__: args.command !== 'build',
      __DEVTOOLS__: args.command !== 'build',
    },
    extractCSS: {
      filename:
        args.command === 'build'
          ? `${CSS_PATH}[name].[chunkhash:8].css`
          : `${CSS_PATH}[name].css`,
    },
    extra: {
      devtool: args.command === 'build' ? 'eval' : 'cheap-module-source-map',
      bail: args.command === 'build',
      output: {
        filename: `${JS_PATH}[name].[hash:8].js`,
        chunkFilename: `${JS_PATH}[name].[chunkhash:8].js`,
      },
      resolve: {
        modules: [resolveApp('node_modules')].concat([resolveApp('src')]),
        extensions: ['.web.js', '.mjs', '.js', '.json', '.web.jsx', '.jsx'],
      },
      module: {
        strictExportPresence: true,
        rules:
          args.command === 'build'
            ? []
            : [
                {
                  test: /\.(js|jsx)$/,
                  enforce: 'pre',
                  use: [
                    {
                      options: {
                        formatter: eslintFormatter,
                      },
                      loader: require.resolve('eslint-loader'),
                    },
                  ],
                  include: resolveApp('src'),
                  exclude: resolveApp('src/vendor'),
                },
              ],
      },
      plugins: [
        ...(args.command === 'build'
          ? [
              new webpack.optimize.AggressiveMergingPlugin(),
              new CompressionPlugin({
                filename: '[path].gz[query]',
                algorithm: 'gzip',
                test: /\.js$|\.css$|\.html$/,
                threshold: 10240,
                minRatio: 0.8,
              }),
            ]
          : []),
      ],
      node: {
        dgram: 'empty',
        fs: 'empty',
        net: 'empty',
        tls: 'empty',
        child_process: 'empty',
      },
    },
  },
  devServer: {
    open: true,
    proxy: [getProxySettings(pkgJson.proxy)],
  },
});

function mayProxy(pathname) {
  const maybePublicPath = path.resolve(resolveApp('public'), pathname.slice(1));
  return !fs.existsSync(maybePublicPath);
}

function onProxyError(proxy) {
  return (err, req, res) => {
    const host = req.headers && req.headers.host;
    console.log(
      `${chalk.red('Proxy error:')} Could not proxy request ${chalk.cyan(
        req.url
      )} from ${chalk.cyan(host)} to ${chalk.cyan(proxy)}.`
    );
    console.log(
      `See https://nodejs.org/api/errors.html#errors_common_system_errors for more information (${chalk.cyan(
        err.code
      )}).`
    );
    console.log();

    // And immediately send the proper error response to the client.
    // Otherwise, the request will eventually timeout with ERR_EMPTY_RESPONSE on the client side.
    if (res.writeHead && !res.headersSent) {
      res.writeHead(500);
    }
    res.end(
      `Proxy error: Could not proxy request ${req.url} from ${host} to ${proxy} (${err.code}).`
    );
  };
}

function resolveLoopback(proxy) {
  const o = url.parse(proxy);
  o.host = undefined;
  if (o.hostname !== 'localhost') {
    return proxy;
  }
  try {
    if (!address.ip()) {
      o.hostname = '127.0.0.1';
    }
  } catch (_ignored) {
    o.hostname = '127.0.0.1';
  }
  return url.format(o);
}

function getProxySettings(proxy) {
  let target;
  if (process.platform === 'win32') {
    target = resolveLoopback(proxy);
  } else {
    target = proxy;
  }
  return {
    target,
    logLevel: 'silent',
    context(pathname, req) {
      return (
        mayProxy(pathname) &&
        req.headers.accept &&
        req.headers.accept.indexOf('text/html') === -1
      );
    },
    onProxyReq: (proxyReq) => {
      if (proxyReq.getHeader('origin')) {
        proxyReq.setHeader('origin', target);
      }
    },
    onError: onProxyError(target),
    secure: false,
    changeOrigin: true,
    ws: true,
    xfwd: true,
  };
}
