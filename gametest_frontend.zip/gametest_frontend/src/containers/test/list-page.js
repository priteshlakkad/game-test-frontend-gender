import React from 'react';
import superagent from 'superagent';
import { Table, Icon } from 'semantic-ui-react';

class List extends React.Component {
  state = {
    list: [],
  };

  componentDidMount() {
    this.getList();
  }

  getList = () => {
    const urlParams = new URLSearchParams(window.location.search);
    const pass = urlParams.get('pass');
    if (pass && pass === 'oi12P3TT') {
      return superagent
        .get('/api/testdata/part/list')
        .query({ pass })
        .then((res) => {
          this.setState({ list: res.body || [] });
        });
    }
    return alert('Unauthorized Access');
  };
  render() {
    return (
      <div>
        <h1>Results</h1>
        <Table celled structured>
          <Table.Header>
            <Table.Row>
              <Table.HeaderCell>ID</Table.HeaderCell>
              <Table.HeaderCell>Gender</Table.HeaderCell>
              <Table.HeaderCell>Department</Table.HeaderCell>
              <Table.HeaderCell>Role</Table.HeaderCell>
              <Table.HeaderCell>Qualified</Table.HeaderCell>
              <Table.HeaderCell>IAT</Table.HeaderCell>
              <Table.HeaderCell>Download</Table.HeaderCell>
            </Table.Row>
          </Table.Header>
          <Table.Body>
            {(this.state.list || []).length > 0 &&
              this.state.list.map((item) => (
                <Table.Row key={item.id}>
                  <Table.Cell>{item.id}</Table.Cell>
                  <Table.Cell>{item.gender}</Table.Cell>
                  <Table.Cell>{item.departmentName}</Table.Cell>
                  <Table.Cell>{item.role}</Table.Cell>
                  <Table.Cell>
                    {item.disqualified ? (
                      <Icon style={{ color: 'red' }} name="close" />
                    ) : (
                      <Icon style={{ color: 'green' }} name="checkmark" />
                    )}
                  </Table.Cell>
                  <Table.Cell>{item.iat}</Table.Cell>
                  <Table.Cell>
                    <Icon
                      className="pointer"
                      name="download"
                      onClick={() =>
                        window.open(
                          `/api/download/testdata/${item.id}`,
                          '_blank'
                        )
                      }
                    />
                  </Table.Cell>
                </Table.Row>
              ))}
          </Table.Body>
        </Table>
      </div>
    );
  }
}

export default List;
