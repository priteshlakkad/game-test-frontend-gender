import React, { Fragment } from 'react';
import { withRouter } from 'react-router-dom';
import { Icon } from 'semantic-ui-react';
import moment from 'moment';

class Box extends React.Component {
  static defaultProps = {
    round: {},
  };

  state = {
    currentKey: 1,
    startTime: moment(),
    prevAnsWrong: false,
    listAns: [],
  };

  onKeyUp = (event) => {
    // keyCode for e = 69
    // keyCode for i = 73
    if (event.keyCode === 69 || event.keyCode === 73) {
      const currentQuestion = this.props.round.questions.find(
        (q) => q.key === this.state.currentKey
      );
      let ans;
      if (event.keyCode === 69) {
        ans = currentQuestion.ans === 1;
      } else if (event.keyCode === 73) {
        ans = currentQuestion.ans === 2;
      }
      if (this.state.prevAnsWrong) {
        if (ans) {
          this.setState({
            prevAnsWrong: false,
            currentKey: this.state.currentKey + 1,
          });
          if (
            (this.state.listAns || []).length === this.props.round.noOfTrials &&
            ans
          ) {
            this.props.onChange({
              listAns: this.state.listAns,
            });
          }
        }
      } else {
        const currentTime = moment();
        const diff = currentTime.diff(this.state.startTime);
        const ansList = [
          ...(this.state.listAns || []),
          {
            answerNumber: currentQuestion.key,
            blockNumber: this.props.round.key,
            results: ans,
            timeTaken: diff,
          },
        ];
        const newState = {
          currentKey: this.state.currentKey + 1,
          listAns: ansList,
          startTime: moment(),
          prevAnsWrong: !ans,
        };
        if (!ans) {
          delete newState.currentKey;
        }
        this.setState(newState);
        if ((ansList || []).length === this.props.round.noOfTrials && ans) {
          delete newState.currentKey;
          this.props.onChange({
            listAns: newState.listAns,
          });
        }
      }
    }
  };
  componentDidMount() {
    document.addEventListener('keyup', this.onKeyUp, false);
  }
  componentWillUnmount() {
    document.removeEventListener('keyup', this.onKeyUp, false);
  }

  getTitle = (title) => {
    const { round } = this.props;
    const value = title.split('+');
    const color = round.color.split('+');
    if (value.length === 1) {
      return <span style={{ color: color[0] }}>{value[0]}</span>;
    }
    return (
      <Fragment>
        <span style={{ color: color[0] }}>{value[0]}</span> +
        <span style={{ color: color[1] }}>{value[1]}</span>
      </Fragment>
    );
  };
  render() {
    const { round } = this.props;
    const { listAns, currentKey, prevAnsWrong } = this.state;
    const currentQuestion = this.props.round.questions.find(
      (q) => q.key === currentKey
    );
    if (!currentQuestion) {
      return <span />;
    }
    return (
      <div className="game-box">
        <div className="header">
          <b>{this.getTitle(round.leftKey)}</b>
          <b className="text-right">{this.getTitle(round.rightKey)}</b>
        </div>
        <div className="content">{currentQuestion.question}</div>
        <div className="result">
          {(listAns || []).length > 0 ? (
            <Fragment>
              {prevAnsWrong ? (
                <Icon style={{ color: 'red' }} name="close" />
              ) : null}
            </Fragment>
          ) : null}
        </div>
      </div>
    );
  }
}

export default withRouter(Box);
