import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
class CompleteStage extends Component {
  componentDidMount() {
    setTimeout(() => {
      this.props.onSubmit();
    }, 300);
  }
  render() {
    return (
      <div>
        <div className="content text-center">
          <p>
            <b>
              Thank you for taking this test. We are proud of you and so should
              you be. You have invested your valuable time to make a difference!
            </b>
          </p>
          <br />
          <p>
            <b>Team Elevate</b>
          </p>
        </div>
      </div>
    );
  }
}

export default withRouter(CompleteStage);
