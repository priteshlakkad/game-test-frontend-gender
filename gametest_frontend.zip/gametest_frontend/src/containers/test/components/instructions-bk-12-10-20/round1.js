import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import { Button } from 'semantic-ui-react';
class Round2 extends Component {
  render() {
    return (
      <div>
        <h1 className="text-center">INSTRUCTIONS FOR ROUND 1</h1>
        <div className="content text-center">
          <p>
            Put your fingers on ‘e’ and ‘i’ keys of your keyboard. Words
            representing the categories at the top will appear one-by-one on the
            screen. When an item belongs to the{' '}
            <span className="highlight"> category on the left, press ‘e’</span>{' '}
            and similarly for item on the{' '}
            <span className="highlight">category to the right, press ‘i’</span>.{' '}
            If you make an error, it will be prompted. You can fix the error by
            pressing the correct key again.
          </p>
          <br />
          <p>
            This is a timed sorting test. GO AS FAST AS YOU CAN while making AS
            FEW MISTAKES AS POSSIBLE.
          </p>
        </div>
        <div className="flex content-center mar-t-20">
          <Button onClick={this.props.onClick}>Start Round 1</Button>
        </div>
      </div>
    );
  }
}

export default withRouter(Round2);
